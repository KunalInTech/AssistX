package com.assistx.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

@Configuration
public class SecurityConfig {

    private final JwtFilter jwtFilter;
    private final OAuthSuccessHandler oAuthSuccessHandler;

    public SecurityConfig(JwtFilter jwtFilter,
                          OAuthSuccessHandler oAuthSuccessHandler) {
        this.jwtFilter = jwtFilter;
        this.oAuthSuccessHandler = oAuthSuccessHandler;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
                // CORS CONFIG
                .cors(cors -> cors.configurationSource(request -> {
                    CorsConfiguration config = new CorsConfiguration();
                    config.setAllowedOrigins(List.of("*"));
                    config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
                    config.setAllowedHeaders(List.of("*"));
                    config.setAllowCredentials(false);
                    return config;
                }))

                // Disable CSRF (for REST APIs)
                .csrf(csrf -> csrf.disable())

                // AUTHORIZATION RULES
                .authorizeHttpRequests(auth -> auth

                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()

                        // PUBLIC PAGES
                        .requestMatchers(
                                "/login.html",
                                "/register.html",
                                "/profile.html",
                                "/user-dashboard.html",
                                "/admin-dashboard.html",
                                "/admin-verify.html",
                                "/oauth2/**",
                                "/login/oauth2/**",
                                "/css/**",
                                "/js/**",
                                "/images/**"
                        ).permitAll()

                        // AUTH APIs
                        .requestMatchers("/api/auth/**").permitAll()

                        // FIXED
                        .requestMatchers("/api/query/**").authenticated()

                        .requestMatchers("/api/user/**").authenticated()

                        .requestMatchers("/api/admin/**").hasRole("ADMIN")

                        // 🔥 IMPORTANT
                        .anyRequest().authenticated()
                )

                // OAUTH LOGIN
                .oauth2Login(oauth -> oauth
                        .loginPage("/login.html")
                        .successHandler(oAuthSuccessHandler)
                )

                // JWT FILTER
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // 🔐 PASSWORD ENCODER (CRITICAL)
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}