package com.assistx.security;

import com.assistx.model.User;
import com.assistx.model.Role;
import com.assistx.repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Optional;

@Component
public class OAuthSuccessHandler implements AuthenticationSuccessHandler {

    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    public OAuthSuccessHandler(UserRepository userRepository,
                               JwtUtil jwtUtil,
                               @Lazy PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.jwtUtil = jwtUtil;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication)
            throws IOException {

        System.out.println("\nOAUTH SUCCESS HANDLER");

        try {
            OAuth2User oauthUser = (OAuth2User) authentication.getPrincipal();

            String email = oauthUser.getAttribute("email");
            String name = oauthUser.getAttribute("name");

            System.out.println("OAuth User Info:");
            System.out.println("   Email: " + email);
            System.out.println("   Name: " + name);

            if (email == null) {
                System.out.println("ERROR: Email not found in OAuth response");
                response.sendRedirect("/login.html?error=oauth");
                return;
            }

            Optional<User> existingUser = userRepository.findByEmail(email);

            User user;

            if (existingUser.isPresent()) {
                user = existingUser.get();
                System.out.println("Existing user found in DB");
            } else {

                System.out.println("Creating new user from OAuth");

                user = new User();
                user.setEmail(email);

                String baseName = (name != null && !name.isBlank())
                        ? name.replaceAll("\\s+", "_")
                        : email.split("@")[0];

                String uniqueUsername = baseName + "_" + System.currentTimeMillis();

                user.setUsername(uniqueUsername);

                // Always encode password
                user.setPassword(passwordEncoder.encode("OAUTH_USER"));

                user.setRole(Role.USER);

                userRepository.save(user);

                System.out.println("New user saved:");
                System.out.println("Username: " + uniqueUsername);
            }

            System.out.println("Final User Details:");
            System.out.println("Email: " + user.getEmail());
            System.out.println("Role: " + user.getRole());

            // Generate JWT
            String token = jwtUtil.generateToken(
                    user.getEmail(),
                    user.getRole().name()
            );

            System.out.println("JWT GENERATED:");
            System.out.println("Token Length: " + token.length());
            System.out.println("+...................................................................Token Preview: " + token.substring(0, 20) + "...");

            // Decide redirect
            String redirectUrl = (user.getRole() == Role.ADMIN)
                    ? "/admin-verify.html?token=" + token
                    : "/user-dashboard.html?token=" + token;

            System.out.println("Redirecting to:");
            System.out.println("   " + redirectUrl);

            System.out.println("\n");

            response.sendRedirect(redirectUrl);

        } catch (Exception e) {

            System.out.println("OAUTH HANDLER ERROR:");
            e.printStackTrace();

            response.sendRedirect("/login.html?error=server");
        }
    }
}