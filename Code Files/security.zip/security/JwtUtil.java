package com.assistx.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    private final String SECRET = "assistx_super_secret_key_assistx_super_secret_key";

    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes());
    }

    // 🔥 FIXED TOKEN GENERATION
    public String generateToken(String email, String role) {

        return Jwts.builder()
                .claim("email", email)
                .claim("role", role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 86400000))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    // FIXED EMAIL EXTRACTION
    public String extractEmail(String token) {

        try {
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(getSigningKey())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();

            return claims.get("email", String.class);

        } catch (Exception e) {
            System.out.println("JWT EMAIL EXTRACT ERROR: " + e.getMessage());
            return null;
        }
    }

    // 🔥 ROLE EXTRACTION (SAFE)
    public String extractRole(String token) {

        try {
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(getSigningKey())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();

            return claims.get("role", String.class);

        } catch (Exception e) {
            System.out.println("JWT ROLE EXTRACT ERROR: " + e.getMessage());
            return null;
        }
    }
}