package com.assistx.service;

import com.assistx.model.Query;
import com.assistx.model.User;
import com.assistx.model.QueryStatus;
import com.assistx.model.ResolutionType;
import com.assistx.repository.QueryRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class QueryService {

    private static final Logger logger = LoggerFactory.getLogger(QueryService.class);

    private final QueryRepository queryRepository;

    public QueryService(QueryRepository queryRepository) {
        this.queryRepository = queryRepository;
    }

    // ================= CREATE QUERY =================
    public Query createQuery(Query query, User user) {

        logger.info("Saving query...");

        query.setUser(user);

        Query saved = queryRepository.save(query);

        logger.info("SAVED QUERY ID: {}", saved.getId());

        return saved;
    }

    // UPDATE QUERY
    public Query updateQuery(Query query) {

        logger.info("Updating query ID: {}", query.getId());

        Query updated = queryRepository.save(query);

        logger.info("Query updated successfully: {}", query.getId());

        return updated;
    }

    // GET USER QUERIES
    public List<Query> getUserQueries(User user) {
        logger.info("Fetching queries for user: {}", user.getEmail());
        return queryRepository.findByUser(user);
    }

    // GET QUERY BY ID
    public Query getQueryById(Long id) {
        logger.info("Fetching query by ID: {}", id);

        return queryRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Query not found: {}", id);
                    return new RuntimeException("Query not found");
                });
    }

    // GET ALL QUERIES
    public List<Query> getAllQueries() {
        logger.info("Fetching ALL queries");
        return queryRepository.findAll();
    }

    // GET ESCALATED
    public List<Query> getAllEscalated() {
        logger.info("Fetching escalated queries");
        return queryRepository.findByEscalatedTrue();
    }

    // WITHDRAW QUERY
    public Query withdrawQuery(Long queryId, User user) {

        logger.info("Withdraw request for Query ID: {}", queryId);

        Query query = queryRepository.findById(queryId)
                .orElseThrow(() -> {
                    logger.error("Query not found: {}", queryId);
                    return new RuntimeException("Query not found");
                });

        // Ownership check
        if (!query.getUser().getUserId().equals(user.getUserId())) {
            logger.error("Unauthorized withdraw attempt by user: {}", user.getEmail());
            throw new RuntimeException("Unauthorized");
        }

        // Only PENDING can be withdrawn
        if (!query.getStatus().equals(QueryStatus.PENDING)) {
            logger.error("Cannot withdraw non-pending query: {}", queryId);
            throw new RuntimeException("Only pending queries can be withdrawn");
        }

        // Update
        query.setStatus(QueryStatus.WITHDRAWN);
        query.setResolutionType(ResolutionType.USER);
        query.setResolvedAt(LocalDateTime.now());

        Query updated = queryRepository.save(query);

        logger.info("Query withdrawn successfully: {}", queryId);

        return updated;
    }
}