package com.assistx.service;

import com.assistx.dto.LoginRequest;
import com.assistx.dto.LoginResponse;
import com.assistx.dto.RegisterRequest;
import com.assistx.model.User;
import com.assistx.repository.UserRepository;
import com.assistx.security.JwtUtil;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    public AuthService(UserRepository userRepository,
                       JwtUtil jwtUtil,
                       PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.jwtUtil = jwtUtil;
        this.passwordEncoder = passwordEncoder;
    }

    // 🔹 REGISTER
    public void register(RegisterRequest request) {

        try {
            User user = new User();

            user.setUsername(request.getUsername().trim());
            user.setEmail(request.getEmail().trim());

            // 🔐 Encode password
            user.setPassword(passwordEncoder.encode(request.getPassword()));

            user.setRole(request.getRole());

            userRepository.save(user);

        } catch (DataIntegrityViolationException e) {
            // 🔥 CLEAN ERROR MESSAGE
            throw new RuntimeException("Email already exists");
        }
    }

    // 🔹 LOGIN (UNCHANGED)
    public LoginResponse login(LoginRequest request) {

        return userRepository
                .findByEmailAndRole(
                        request.getEmail().trim(),
                        request.getRole()
                )
                .filter(user ->
                        passwordEncoder.matches(
                                request.getPassword(),
                                user.getPassword()
                        )
                )
                .map(user -> {

                    String token = jwtUtil.generateToken(
                            user.getEmail(),
                            user.getRole().name()
                    );

                    return new LoginResponse(
                            true,
                            "Login successful",
                            token,
                            user.getRole().name()
                    );
                })
                .orElse(new LoginResponse(
                        false,
                        "Invalid credentials",
                        null,
                        null
                ));
    }
}