package com.assistx.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;

import java.util.*;

@Service
public class GeminiService {

    private static final Logger logger = LoggerFactory.getLogger(GeminiService.class);

    private final String API_KEY = System.getProperty("GEMINI_API_KEY");
    private final String URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=";

    // MAIN METHOD
    public String generateResponse(String userMessage, String context) {

        logger.info("GeminiService: Received user message: {}", userMessage);

        if (API_KEY == null || API_KEY.isEmpty()) {
            logger.error("GEMINI_API_KEY is NULL or EMPTY");
            return "Server configuration error. [ESCALATE]";
        }

        RestTemplate restTemplate = new RestTemplate();

        // UPGRADED PROMPT
        String prompt = """
                You are AssistX AI support assistant.
                
Handles: account, orders, shipping, delivery, invoice, payment, refund, cancellation, subscription, technical, warranty, feedback, support.
                
Rules: Help step-by-step; Ask for required info; Be concise
                
CRITICAL INSTRUCTIONS:
                
You MUST ALWAYS end your response with ONE of these tags:
                
[RESOLVED] → if issue is fully solved
[ESCALATE] → if unsure OR needs human help
[CONTINUE] → if conversation should continue
                
The tag MUST be the FINAL text in the response.DO NOT add any text after the tag.
The tag is for system use only. DO NOT explain it.
                
ESCALATE when:
- Missing critical info after asking once
- User repeats issue or shows frustration
- Requires account/order verification
- Requires human/system access
- You are unsure
                
Do not ask the same question more than twice.
If still unresolved → ESCALATE.
                
IMPORTANT:
- DO NOT claim access to databases or systems
- DO NOT say "I will check" or "I will fetch"
- If unsure → ESCALATE
- If partial → CONTINUE
- If solved → RESOLVED
                
Examples:
"I have guided you through the fix. Please try again. [RESOLVED]"
"I need your order ID to proceed. [CONTINUE]"
"This requires human support intervention. [ESCALATE]"
                
Conversation:
""" + context + """

User: """ + userMessage;

        // ================= REQUEST BODY =================
        Map<String, Object> text = Map.of("text", prompt);
        Map<String, Object> part = Map.of("parts", List.of(text));
        Map<String, Object> body = Map.of("contents", List.of(part));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);

        try {
            logger.info("Sending request to Gemini API...");

            ResponseEntity<Map> response = restTemplate.exchange(
                    URL + API_KEY,
                    HttpMethod.POST,
                    request,
                    Map.class
            );

            logger.info("Gemini API responded with status: {}", response.getStatusCode());

            String extracted = extractText(response.getBody());

            logger.info("Extracted AI Response: {}", extracted);

            return extracted;

        } catch (Exception e) {
            logger.error("Error while calling Gemini API", e);

            // IMPORTANT: fallback escalates automatically
            return "We are facing technical issues. Our support team will assist you shortly. [ESCALATE]";
        }
    }

    // RESPONSE PARSER
    private String extractText(Map<String, Object> response) {

        if (response == null) {
            logger.error("Gemini response is NULL");
            return "No response from AI. [ESCALATE]";
        }

        try {
            List candidates = (List) response.get("candidates");

            if (candidates == null || candidates.isEmpty()) {
                logger.error("No candidates found in response: {}", response);
                return "AI returned no candidates. [ESCALATE]";
            }

            Map first = (Map) candidates.get(0);
            Map content = (Map) first.get("content");
            List parts = (List) content.get("parts");

            if (parts == null || parts.isEmpty()) {
                logger.error("No parts found in response: {}", response);
                return "AI response format invalid. [ESCALATE]";
            }

            String text = (String) ((Map) parts.get(0)).get("text");

            if (text == null || text.isEmpty()) {
                logger.error("Extracted text is empty: {}", response);
                return "AI returned empty response. [ESCALATE]";
            }

            return text;

        } catch (Exception e) {
            logger.error("Error parsing Gemini response: {}", response, e);
            return "Unable to process response. [ESCALATE]";
        }
    }
}