package com.assistx.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class AIService {

    private static final Logger logger = LoggerFactory.getLogger(AIService.class);

    private final String CLASSIFY_URL = "http://127.0.0.1:5000/predict";

    public Map<String, Object> classifyQuery(String queryText) {

        logger.info("Sending query to FastAPI: {}", queryText);

        RestTemplate restTemplate = new RestTemplate();

        Map<String, String> request = new HashMap<>();
        request.put("text", queryText);

        try {
            Map<String, Object> response = restTemplate.postForObject(
                    CLASSIFY_URL,
                    request,
                    Map.class
            );

            logger.info("FastAPI Response: {}", response);

            return response;

        } catch (Exception e) {
            logger.error("Error calling FastAPI", e);
            throw new RuntimeException("FastAPI call failed");
        }
    }
}