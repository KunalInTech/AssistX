package com.assistx.service;

import com.assistx.dto.UserRegistryDTO;
import com.assistx.dto.UserDetailsDTO;
import com.assistx.model.Role;
import com.assistx.model.User;
import com.assistx.model.Query;
import com.assistx.model.QueryStatus;
import com.assistx.repository.UserRepository;
import com.assistx.repository.QueryRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.ArrayList;

@Service
public class AdminService {

    private final UserRepository userRepository;
    private final QueryRepository queryRepository;

    // Constructor Injection
    public AdminService(UserRepository userRepository,
                        QueryRepository queryRepository) {
        this.userRepository = userRepository;
        this.queryRepository = queryRepository;
    }

    // USER REGISTRY
    public List<UserRegistryDTO> getAllUsers(String search) {

        // Fetch ONLY USERS
        List<User> users = userRepository.findByRole(Role.USER);

        // Apply search
        if (search != null && !search.isBlank()) {

            String searchLower = search.toLowerCase();

            users = users.stream()
                    .filter(user ->
                            user.getUsername().toLowerCase().contains(searchLower) ||
                                    user.getEmail().toLowerCase().contains(searchLower)
                    )
                    .toList();
        }

        // Map to DTO
        return users.stream()
                .map(user -> new UserRegistryDTO(
                        user.getUserId(),
                        user.getUsername(),
                        user.getEmail(),
                        user.getLastActiveAt()
                ))
                .toList();
    }

    //USER DETAILS
    public UserDetailsDTO getUserDetails(Long userId) {

        // Fetch user
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Fetch queries
        List<Query> queries = queryRepository.findByUser(user);

        int total = queries.size();
        int pending = 0;
        int resolved = 0;
        int escalated = 0;
        int withdrawn = 0;

        List<UserDetailsDTO.QueryInfo> queryInfos = new ArrayList<>();

        for (Query q : queries) {

            if (q.getStatus() == QueryStatus.PENDING) pending++;
            else if (q.getStatus() == QueryStatus.RESOLVED) resolved++;
            else if (q.getStatus() == QueryStatus.ESCALATED) escalated++;
            else if (q.getStatus() == QueryStatus.WITHDRAWN) withdrawn++;

            queryInfos.add(new UserDetailsDTO.QueryInfo(
                    q.getId(),
                    q.getStatus().name(),
                    q.getDescription(),
                    q.getCreatedAt()
            ));
        }

        return new UserDetailsDTO(
                user.getUserId(),
                user.getUsername(),
                user.getEmail(),
                total,
                pending,
                resolved,
                escalated,
                withdrawn,
                queryInfos
        );
    }
}