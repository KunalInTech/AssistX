package com.assistx.controller;

import com.assistx.model.Query;
import com.assistx.model.User;
import com.assistx.repository.UserRepository;
import com.assistx.service.AIService;
import com.assistx.service.QueryService;
import com.assistx.service.GeminiService;
import com.assistx.dto.CreateQueryRequest;
import com.assistx.dto.SendMessageRequest;
import com.assistx.model.Message;
import com.assistx.model.SenderType;
import com.assistx.repository.MessageRepository;
import com.assistx.model.QueryStatus;
import com.assistx.model.ResolutionType;
import com.assistx.dto.UserQueryDTO;

import jakarta.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/query")
@CrossOrigin
public class QueryController {

    private static final Logger logger = LoggerFactory.getLogger(QueryController.class);

    private final AIService aiService;
    private final QueryService queryService;
    private final UserRepository userRepository;
    private final GeminiService geminiService;
    private final MessageRepository messageRepository;

    public QueryController(AIService aiService,
                           QueryService queryService,
                           UserRepository userRepository,
                           GeminiService geminiService,
                           MessageRepository messageRepository) {
        this.aiService = aiService;
        this.queryService = queryService;
        this.userRepository = userRepository;
        this.geminiService = geminiService;
        this.messageRepository = messageRepository;
    }

    @PostConstruct
    public void init() {
        logger.info("QueryController LOADED");
    }

    // AI TEST (optional)
    @PostMapping("/classify")
    public Map<String, Object> classify(@RequestBody Map<String, String> body) {
        logger.info("Classify endpoint hit with text: {}", body.get("text"));
        return aiService.classifyQuery(body.get("text"));
    }

    // CREATE QUERY
    @PostMapping("/create")
    public Query createQuery(@RequestBody CreateQueryRequest req, Authentication auth) {

        logger.info(" CREATE QUERY START ");

        try {
            if (auth == null) {
                logger.error("AUTH IS NULL");
                throw new ResponseStatusException(
                        HttpStatus.UNAUTHORIZED,
                        "Please login first"
                );
            }

            String email = auth.getName();
            logger.info("AUTHENTICATED USER: {}", email);

            User user = userRepository.findByEmail(email)
                    .orElseThrow(() -> {
                        logger.error("USER NOT FOUND IN DB for email: {}", email);
                        return new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "User not found"
                        );
                    });

            logger.info("USER FOUND: {}", user.getEmail());

            if (req.getDescription() == null || req.getDescription().isBlank()) {
                logger.error(" DESCRIPTION IS EMPTY");
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Description is required"
                );
            }

            String userMessage = req.getDescription();

            // AI CLASSIFICATION
            Map<String, Object> aiResult;

            try {
                aiResult = aiService.classifyQuery(userMessage);
            } catch (Exception e) {
                logger.error("ML classification failed", e);

                aiResult = Map.of(
                        "category", "unknown",
                        "confidence", 0.0
                );
            }

            String category = (String) aiResult.get("category");
            double confidence = ((Number) aiResult.get("confidence")).doubleValue();

            logger.info(" AI Classification → Category: {}, Confidence: {}", category, confidence);

            // DECISION LOGIC
            String aiResponse = null;
            boolean escalated = false;

            if (confidence < 0.75) {
                logger.warn("Low confidence → Escalating to admin");
                escalated = true;
            } else {
                logger.info("High confidence → Calling Gemini");
                try {
                    aiResponse = geminiService.generateResponse(userMessage, "");
                } catch (Exception e) {
                    logger.error("Gemini failed", e);
                    aiResponse = "We have received your query. Our support team will assist you shortly.";
                    escalated = true;
                }
                logger.info("Gemini Response Generated");
            }

            // FIX 2: Prevent null response
            if (aiResponse == null) {
                aiResponse = "Your query has been forwarded to our support team.";
            }

            // CREATE QUERY
            Query query = new Query();

            query.setUser(user);
            query.setCategory(category);
            query.setDescription(userMessage);

            // FIX 1: Save AI metadata
            query.setAiCategory(category);
            query.setConfidence(confidence);

            query.setAiResponse(aiResponse);
            query.setEscalated(escalated);

            if (req.getProductName() != null && !req.getProductName().isBlank()) {
                query.setProductName(req.getProductName());
            }

            if (req.getPurchaseDate() != null && !req.getPurchaseDate().isBlank()) {
                try {
                    query.setPurchaseDate(java.time.LocalDate.parse(req.getPurchaseDate()));
                } catch (Exception e) {
                    logger.error("DATE PARSE FAILED: {}", req.getPurchaseDate(), e);
                }
            }

            Query savedQuery = queryService.createQuery(query, user);

            // SAVE MESSAGES
            Message userMsg = new Message();
            userMsg.setQuery(savedQuery);
            userMsg.setSender(SenderType.USER);
            userMsg.setContent(userMessage);
            messageRepository.save(userMsg);

            Message aiMsg = new Message();
            aiMsg.setQuery(savedQuery);
            aiMsg.setSender(SenderType.AI);
            aiMsg.setContent(aiResponse);
            messageRepository.save(aiMsg);

            logger.info("QUERY SAVED SUCCESSFULLY! ID: {}", savedQuery.getId());

            return savedQuery;

        } catch (Exception e) {
            logger.error("ERROR INSIDE CREATE QUERY", e);
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Internal error: " + e.getMessage()
            );
        }
    }

    // GET USER QUERIES
    @GetMapping("/my")
    public List<UserQueryDTO> getMyQueries(Authentication auth) {

        if (auth == null) {
            logger.error("Unauthorized access to /my queries");
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Please login first"
            );
        }

        String email = auth.getName();
        logger.info("Fetching queries for user: {}", email);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> {
                    logger.error("USER NOT FOUND for email: {}", email);
                    return new ResponseStatusException(
                            HttpStatus.NOT_FOUND,
                            "User not found"
                    );
                });

        return queryService.getUserQueries(user)
                .stream()
                .map(q -> new UserQueryDTO(
                        q.getId(),
                        q.getDescription(),
                        q.getStatus().name(),
                        q.getCreatedAt().toString()
                ))
                .toList();
    }

    // WITHDRAW QUERY
    @PostMapping("/withdraw/{id}")
    public Query withdraw(@PathVariable Long id, Authentication auth) {

        if (auth == null) {
            logger.error("Unauthorized withdraw attempt");
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Please login first"
            );
        }

        String email = auth.getName();
        logger.info("Withdraw request for Query ID: {} by user: {}", id, email);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> {
                    logger.error(" USER NOT FOUND for email: {}", email);
                    return new ResponseStatusException(
                            HttpStatus.NOT_FOUND,
                            "User not found"
                    );
                });

        return queryService.withdrawQuery(id, user);
    }

    @PostMapping("/{id}/messages")
    public Message sendMessage(@PathVariable Long id,
                               @RequestBody SendMessageRequest req,
                               Authentication auth) {

        logger.info("SEND MESSAGE START for Query ID: {}", id);

        try {
            if (auth == null) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Please login first");
            }

            String email = auth.getName();

            User user = userRepository.findByEmail(email)
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.NOT_FOUND, "User not found"
                    ));

            Query query = queryService.getQueryById(id);

            // BLOCK IF CLOSED
            if (query.getStatus() == QueryStatus.RESOLVED ||
                    query.getStatus() == QueryStatus.WITHDRAWN) {

                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "This query is already closed"
                );
            }

            String userMessage = req.getMessage();

            if (userMessage == null || userMessage.isBlank()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Message cannot be empty"
                );
            }

            // SAVE USER MESSAGE
            Message userMsg = new Message();
            userMsg.setQuery(query);
            userMsg.setSender(SenderType.USER);
            userMsg.setContent(userMessage);

            messageRepository.save(userMsg);

            // BUILD CONTEXT
            List<Message> messages =
                    messageRepository.findByQueryOrderByTimestampAsc(query);

            int start = Math.max(0, messages.size() - 6);
            List<Message> recentMessages = messages.subList(start, messages.size());

            StringBuilder contextBuilder = new StringBuilder();

            for (Message m : recentMessages) {
                if (m.getSender() == SenderType.USER) {
                    contextBuilder.append("User: ").append(m.getContent()).append("\n");
                } else if (m.getSender() == SenderType.AI) {
                    contextBuilder.append("AI: ").append(m.getContent()).append("\n");
                }
            }

            String context = contextBuilder.toString();

            // DECIDE AI OR ADMIN
            String aiResponse;

            if (Boolean.TRUE.equals(query.getEscalated())) {

                logger.info("Query already escalated → waiting for admin");

                aiResponse = "Our support team will respond shortly.";

            } else {

                try {
                    logger.info("Calling Gemini with context...");
                    aiResponse = geminiService.generateResponse(userMessage, context);

                    String upper = aiResponse.toUpperCase();

                    // LLM DECISION ENGINE

                    if (upper.contains("[ESCALATE]")) {

                        logger.warn("LLM triggered escalation");

                        query.setStatus(QueryStatus.ESCALATED);
                        query.setEscalated(true);

                        queryService.updateQuery(query);

                        aiResponse = aiResponse.replace("[ESCALATE]", "").trim();

                    } else if (upper.contains("[RESOLVED]")) {

                        logger.info("LLM auto-resolved query");

                        query.setStatus(QueryStatus.RESOLVED);
                        query.setResolutionType(ResolutionType.AI);

                        queryService.updateQuery(query);

                        aiResponse = aiResponse.replace("[RESOLVED]", "").trim();

                    } else {

                        // CONTINUE
                        aiResponse = aiResponse.replace("[CONTINUE]", "").trim();
                    }

                } catch (Exception e) {

                    logger.error("Gemini failed during chat", e);

                    aiResponse = "We are facing technical issues. Our support team will assist you shortly.";

                    query.setStatus(QueryStatus.ESCALATED);
                    query.setEscalated(true);

                    queryService.updateQuery(query);
                }
            }

            // SAVE AI MESSAGE
            Message aiMsg = new Message();
            aiMsg.setQuery(query);
            aiMsg.setSender(SenderType.AI);
            aiMsg.setContent(aiResponse);

            messageRepository.save(aiMsg);

            logger.info("SEND MESSAGE END");

            return aiMsg;

        } catch (Exception e) {
            logger.error("ERROR IN SEND MESSAGE", e);
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Error: " + e.getMessage()
            );
        }
    }

    @GetMapping("/{id}/messages")
    public List<Message> getMessages(@PathVariable Long id, Authentication auth) {

        logger.info("FETCH MESSAGES for Query ID: {}", id);

        if (auth == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Please login first");
        }

        Query query = queryService.getQueryById(id);

        return messageRepository.findByQueryOrderByTimestampAsc(query);
    }

}