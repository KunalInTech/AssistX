package com.assistx.controller;

import com.assistx.dto.SendMessageRequest;
import com.assistx.dto.UserRegistryDTO;
import com.assistx.dto.UserDetailsDTO;
import com.assistx.dto.QueryAdminDTO;

import com.assistx.model.*;
import com.assistx.repository.MessageRepository;
import com.assistx.service.QueryService;
import com.assistx.service.AdminService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Comparator;
import java.util.Map;
import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    private final QueryService queryService;
    private final MessageRepository messageRepository;
    private final AdminService adminService;

    public AdminController(QueryService queryService,
                           MessageRepository messageRepository,
                           AdminService adminService) {
        this.queryService = queryService;
        this.messageRepository = messageRepository;
        this.adminService = adminService;
    }

    // AUTH
    private void validateAdmin(String adminSecret) {
        if (adminSecret == null || !adminSecret.equals(System.getProperty("ADMIN_SECRET"))) {
            logger.error("Invalid ADMIN_SECRET attempt");
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid admin access");
        }
    }

    // ADMIN REPLY
    @PostMapping("/{id}/reply")
    public Message adminReply(@PathVariable Long id,
                              @RequestBody SendMessageRequest req,
                              @RequestHeader("ADMIN_SECRET") String adminSecret) {

        validateAdmin(adminSecret);

        Query query = queryService.getQueryById(id);

        //Block closed queries
        if (query.getStatus() == QueryStatus.RESOLVED ||
                query.getStatus() == QueryStatus.WITHDRAWN) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Query already closed"
            );
        }

        String message = req.getMessage();

        if (message == null || message.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Message cannot be empty");
        }

        Message adminMsg = new Message();
        adminMsg.setQuery(query);
        adminMsg.setSender(SenderType.ADMIN);
        adminMsg.setContent(message);

        messageRepository.save(adminMsg);

        logger.info("Admin replied to Query ID: {}", id);

        return adminMsg;
    }

    // ================= RESOLVE =================
    @PostMapping("/{id}/resolve")
    public Query resolveQuery(@PathVariable Long id,
                              @RequestHeader("ADMIN_SECRET") String adminSecret) {

        validateAdmin(adminSecret);

        Query query = queryService.getQueryById(id);

        //Block closed queries
        if (query.getStatus() == QueryStatus.RESOLVED ||
                query.getStatus() == QueryStatus.WITHDRAWN) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Query already closed"
            );
        }

        query.setStatus(QueryStatus.RESOLVED);
        query.setResolutionType(ResolutionType.ADMIN);

        Query updated = queryService.updateQuery(query);

        logger.info("Query resolved → ID: {}", id);

        return updated;
    }

    // ESCALATE
    @PostMapping("/{id}/escalate")
    public Query escalateQuery(@PathVariable Long id,
                               @RequestHeader("ADMIN_SECRET") String adminSecret) {

        validateAdmin(adminSecret);

        Query query = queryService.getQueryById(id);

        //Block closed queries
        if (query.getStatus() == QueryStatus.RESOLVED ||
                query.getStatus() == QueryStatus.WITHDRAWN) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Query already closed"
            );
        }

        query.setStatus(QueryStatus.ESCALATED);

        Query updated = queryService.updateQuery(query);

        logger.info("Query escalated → ID: {}", id);

        return updated;
    }

    // GET ALL QUERIES (DTO)
    @GetMapping("/all")
    public List<QueryAdminDTO> getAllQueries(@RequestHeader("ADMIN_SECRET") String adminSecret) {

        validateAdmin(adminSecret);

        return queryService.getAllQueries()
                .stream()
                .map(q -> new QueryAdminDTO(
                        q.getId(),
                        q.getDescription(),
                        q.getStatus().name(),
                        q.getCreatedAt(),
                        q.getUser().getUsername()
                ))
                .toList();
    }

    // USER REGISTRY
    @GetMapping("/users")
    public List<UserRegistryDTO> getUsers(
            @RequestParam(required = false) String search,
            @RequestHeader("ADMIN_SECRET") String adminSecret) {

        validateAdmin(adminSecret);

        return adminService.getAllUsers(search);
    }

    // USER DETAILS
    @GetMapping("/user/{id}")
    public UserDetailsDTO getUserDetails(@PathVariable Long id,
                                         @RequestHeader("ADMIN_SECRET") String adminSecret) {

        validateAdmin(adminSecret);
        return adminService.getUserDetails(id);
    }

    //ESCALATED ONLY
    @GetMapping("/escalated")
    public List<QueryAdminDTO> getEscalatedQueries(
            @RequestHeader("ADMIN_SECRET") String adminSecret) {

        validateAdmin(adminSecret);

        return queryService.getAllQueries()
                .stream()
                .filter(q -> q.getStatus() == QueryStatus.ESCALATED)
                .sorted(Comparator.comparing(Query::getCreatedAt))
                .map(q -> new QueryAdminDTO(
                        q.getId(),
                        q.getDescription(),
                        q.getStatus().name(),
                        q.getCreatedAt(),
                        q.getUser().getUsername()
                ))
                .toList();
    }

    @GetMapping("/analytics")
    public Map<String, Object> getAnalytics(
            @RequestHeader("ADMIN_SECRET") String adminSecret) {

        validateAdmin(adminSecret);

        List<Query> queries = queryService.getAllQueries();

        long total = queries.size();

        long pending = queries.stream()
                .filter(q -> q.getStatus() == QueryStatus.PENDING)
                .count();

        long resolved = queries.stream()
                .filter(q -> q.getStatus() == QueryStatus.RESOLVED)
                .count();

        long withdrawn = queries.stream()
                .filter(q -> q.getStatus() == QueryStatus.WITHDRAWN)
                .count();

        long escalated = queries.stream()
                .filter(q -> Boolean.TRUE.equals(q.getEscalated()))
                .count();

        long aiResolved = queries.stream()
                .filter(q -> q.getResolutionType() == ResolutionType.AI)
                .count();

        long adminResolved = queries.stream()
                .filter(q -> q.getResolutionType() == ResolutionType.ADMIN)
                .count();

        // AVG RESOLUTION TIME (in minutes)
        double avgResolutionTime = queries.stream()
                .filter(q -> q.getResolvedAt() != null)
                .mapToLong(q ->
                        java.time.Duration.between(
                                q.getCreatedAt(),
                                q.getResolvedAt()
                        ).toMinutes()
                )
                .average()
                .orElse(0);

        Map<String, Object> result = new HashMap<>();

        result.put("total", total);
        result.put("pending", pending);
        result.put("resolved", resolved);
        result.put("withdrawn", withdrawn);
        result.put("escalated", escalated);
        result.put("aiResolved", aiResolved);
        result.put("adminResolved", adminResolved);
        result.put("avgResolutionTime", avgResolutionTime);

        return result;
    }
}