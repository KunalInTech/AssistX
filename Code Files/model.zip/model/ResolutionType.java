package com.assistx.model;

public enum ResolutionType {
    ADMIN,
    USER,
    AI
}