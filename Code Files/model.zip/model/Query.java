package com.assistx.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "query")
public class Query {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // USER
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // USER INPUT
    private String category;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "purchase_date")
    private LocalDate purchaseDate;

    @Column(nullable = false, length = 2000)
    private String description;

    //AI OUTPUT
    @Column(name = "ai_category")
    private String aiCategory;

    private Double confidence;

    //AI FIRST RESPONSE
    @Column(name = "ai_response", length = 5000)
    private String aiResponse;

    // ESCALATION FLAG
    @Column(name = "is_escalated")
    private Boolean escalated;

    //STATUS
    @Enumerated(EnumType.STRING)
    private QueryStatus status;

    // RESOLUTION TYPE
    @Enumerated(EnumType.STRING)
    private ResolutionType resolutionType;

    // TIME TRACKING
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt;

    // DEFAULTS
    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
        this.status = QueryStatus.PENDING;
        this.escalated = false; // IMPORTANT
    }

    // UPDATE HOOK
    @PreUpdate
    public void preUpdate() {
        if (this.status == QueryStatus.RESOLVED && this.resolvedAt == null) {
            this.resolvedAt = LocalDateTime.now();
        }
    }

    // GETTERS & SETTERS

    public Long getId() { return id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public LocalDate getPurchaseDate() { return purchaseDate; }
    public void setPurchaseDate(LocalDate purchaseDate) { this.purchaseDate = purchaseDate; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getAiCategory() { return aiCategory; }
    public void setAiCategory(String aiCategory) { this.aiCategory = aiCategory; }

    public Double getConfidence() { return confidence; }
    public void setConfidence(Double confidence) { this.confidence = confidence; }

    public String getAiResponse() { return aiResponse; }
    public void setAiResponse(String aiResponse) { this.aiResponse = aiResponse; }

    public Boolean getEscalated() { return escalated; }
    public void setEscalated(Boolean escalated) { this.escalated = escalated; }

    public QueryStatus getStatus() { return status; }
    public void setStatus(QueryStatus status) { this.status = status; }

    public ResolutionType getResolutionType() { return resolutionType; }
    public void setResolutionType(ResolutionType resolutionType) { this.resolutionType = resolutionType; }

    public LocalDateTime getCreatedAt() { return createdAt; }

    public LocalDateTime getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(LocalDateTime resolvedAt) { this.resolvedAt = resolvedAt; }
}