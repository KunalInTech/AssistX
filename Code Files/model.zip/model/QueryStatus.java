package com.assistx.model;

public enum QueryStatus {
    PENDING,
    RESOLVED,
    ESCALATED,
    WITHDRAWN
}