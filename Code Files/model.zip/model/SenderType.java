package com.assistx.model;

public enum SenderType {
    USER,
    AI,
    ADMIN
}