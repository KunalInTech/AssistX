package com.assistx.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "message")
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // LINK TO QUERY (TICKET)
    @ManyToOne
    @JoinColumn(name = "query_id", nullable = false)
    private Query query;

    // WHO SENT IT
    @Enumerated(EnumType.STRING)
    private SenderType sender;

    // MESSAGE CONTENT
    @Column(nullable = false, length = 5000)
    private String content;

    // TIMESTAMP
    private LocalDateTime timestamp;

    @PrePersist
    public void prePersist() {
        this.timestamp = LocalDateTime.now();
    }

    // GETTERS & SETTERS

    public Long getId() { return id; }

    public Query getQuery() { return query; }
    public void setQuery(Query query) { this.query = query; }

    public SenderType getSender() { return sender; }
    public void setSender(SenderType sender) { this.sender = sender; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public LocalDateTime getTimestamp() { return timestamp; }
}