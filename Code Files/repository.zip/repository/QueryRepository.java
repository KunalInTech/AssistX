package com.assistx.repository;

import com.assistx.model.Query;
import com.assistx.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QueryRepository extends JpaRepository<Query, Long> {

    List<Query> findByUser(User user);
    List<Query> findByEscalatedTrue();

}