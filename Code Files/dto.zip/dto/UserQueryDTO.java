package com.assistx.dto;

public class UserQueryDTO {

    private Long id;
    private String description;
    private String status;
    private String createdAt;

    // CONSTRUCTOR
    public UserQueryDTO(Long id, String description, String status, String createdAt) {
        this.id = id;
        this.description = description;
        this.status = status;
        this.createdAt = createdAt;
    }

    // GETTERS

    public Long getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }

    public String getCreatedAt() {
        return createdAt;
    }
}