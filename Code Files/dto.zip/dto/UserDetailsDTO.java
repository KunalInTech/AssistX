package com.assistx.dto;

import java.time.LocalDateTime;
import java.util.List;

public class UserDetailsDTO {

    public Long userId;
    public String username;
    public String email;

    public int totalQueries;
    public int pending;
    public int resolved;
    public int escalated;
    public int withdrawn;

    public List<QueryInfo> queries;

    public static class QueryInfo {
        public Long queryId;
        public String status;
        public String description; // 🔥 NEW
        public LocalDateTime createdAt;

        public QueryInfo(Long queryId, String status, String description, LocalDateTime createdAt) {
            this.queryId = queryId;
            this.status = status;
            this.description = description;
            this.createdAt = createdAt;
        }
    }

    public UserDetailsDTO(Long userId, String username, String email,
                          int totalQueries, int pending, int resolved, int escalated, int withdrawn,
                          List<QueryInfo> queries) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.totalQueries = totalQueries;
        this.pending = pending;
        this.resolved = resolved;
        this.escalated = escalated;
        this.withdrawn = withdrawn;
        this.queries = queries;
    }
}