package com.assistx.dto;

public class UpdateUsernameRequest {
    public String username;
}