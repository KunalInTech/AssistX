package com.assistx.dto;

public class LoginResponse {

    private boolean success;
    private String message;
    private String token;
    private String role;

    public LoginResponse(boolean success, String message, String token, String role) {
        this.success = success;
        this.message = message;
        this.token = token;
        this.role = role;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public String getRole() {
        return role;
    }

    public String getToken() {return token;}
}
