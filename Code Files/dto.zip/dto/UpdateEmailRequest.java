package com.assistx.dto;

public class UpdateEmailRequest {
    public String email;
    public String password;
}