package com.assistx.dto;

import java.time.LocalDateTime;

public class UserRegistryDTO {

    private Long id;
    private String username;
    private String email;
    private LocalDateTime lastActiveAt;

    public UserRegistryDTO(Long id, String username, String email, LocalDateTime lastActiveAt) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.lastActiveAt = lastActiveAt;
    }

    public Long getId() { return id; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public LocalDateTime getLastActiveAt() { return lastActiveAt; }
}