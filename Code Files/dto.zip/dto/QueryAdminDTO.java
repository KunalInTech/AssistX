package com.assistx.dto;

import java.time.LocalDateTime;

public class QueryAdminDTO {

    private Long queryId;
    private String description;
    private String status;
    private LocalDateTime createdAt;
    private String username;

    public QueryAdminDTO(Long queryId,
                         String description,
                         String status,
                         LocalDateTime createdAt,
                         String username) {
        this.queryId = queryId;
        this.description = description;
        this.status = status;
        this.createdAt = createdAt;
        this.username = username;
    }

    public Long getQueryId() {
        return queryId;
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public String getUsername() {
        return username;
    }
}