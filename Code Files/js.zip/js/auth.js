const API_BASE = "http://localhost:8080/api/auth";

// TOKEN VALIDATOR (CRITICAL FIX)
function isValidToken(token) {
    return token && token.includes(".") && token.split(".").length === 3;
}

function register() {

    const username = document.getElementById("registerUsername").value.trim();
    const email = document.getElementById("registerEmail").value.trim();
    const password = document.getElementById("registerPassword").value.trim();
    const role = document.getElementById("registerRole").value;

    const msg = document.getElementById("registerMessage");

    // Reset message
    msg.innerText = "";
    msg.style.color = "#f87171";

    // Validation
    if (!username || !email || !password) {
        msg.innerText = "All fields are required";
        return;
    }

    if (username.length < 3) {
        msg.innerText = "Username must be at least 3 characters";
        return;
    }

    if (password.length < 6) {
        msg.innerText = "Password must be at least 6 characters";
        return;
    }

    const data = { username, email, password, role };

    fetch(`${API_BASE}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(async (res) => {

        const text = await res.text();

        // 🔥 CRITICAL FIX: handle backend errors properly
        if (!res.ok) {
            throw new Error(text || "Registration failed");
        }

        return text;
    })
    .then((msgText) => {

        msg.style.color = "lightgreen";
        msg.innerText = msgText || "Registration successful";

        // Redirect after success
        setTimeout(() => {
            window.location.href = "/login.html";
        }, 1200);
    })
    .catch((err) => {

        msg.style.color = "#f87171";
        msg.innerText = err.message || "Registration failed. Please try again.";
    });
}

// ================= GOOGLE LOGIN =================
function googleLogin() {
    window.location.href =
        "http://localhost:8080/oauth2/authorization/google?prompt=consent select_account";
}

// ================= LOGOUT =================
function logout() {

    const token = localStorage.getItem("token");

    // FIX: Only call backend if token is valid
    if (isValidToken(token)) {
        fetch(`${API_BASE}/logout`, {
            method: "POST",
            headers: {
                "Authorization": "Bearer " + token
            }
        }).finally(clearSession);
    } else {
        clearSession();
    }
}

// Clean logout helper
function clearSession() {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    window.location.href = "/login.html";
}