document.addEventListener("DOMContentLoaded", () => {

    if (typeof startParticles === "function") {
        startParticles();
    }

    const params = new URLSearchParams(window.location.search);

    // Correct param names
    const queryId = params.get("id") || params.get("queryId");
    const isAdmin = params.get("admin") === "true";

    if (!queryId) {
        alert("Invalid query");
        redirectBack(isAdmin);
        return;
    }

    console.log("Opened chat for query:", queryId, "Admin:", isAdmin);

    // store globally
    window.currentQueryId = queryId;
    window.isAdmin = isAdmin;

    loadMessages(queryId);
    loadQueryMeta(queryId, isAdmin);
});


// LOAD META
function loadQueryMeta(queryId, isAdmin) {

    const token = localStorage.getItem("token");

    // Different API for admin vs user
    const url = isAdmin
        ? `http://localhost:8080/api/admin/all`
        : `http://localhost:8080/api/query/my`;

    const headers = {
        "Authorization": "Bearer " + token
    };

    // Admin needs secret
    if (isAdmin) {
        headers["ADMIN_SECRET"] = sessionStorage.getItem("admin_secret");
    }

    fetch(url, { headers })
    .then(res => res.json())
    .then(data => {

        const query = data.find(q =>
            (q.id || q.queryId) == queryId
        );

        if (!query) {
            alert("Invalid query");
            redirectBack(isAdmin);
            return;
        }

        console.log("Query meta:", query);

        // STATUS
        const statusEl = document.getElementById("queryStatus");
        if (statusEl) {
            statusEl.innerText = `Status: ${query.status}`;
        }

        // DISABLE INPUT IF CLOSED
        const isClosed = (query.status === "RESOLVED" || query.status === "WITHDRAWN");

        document.getElementById("messageInput").disabled = isClosed;
        document.getElementById("sendBtn").disabled = isClosed;

        // ESCALATION BANNER
        //support BOTH old boolean + new status system
        if (query.escalated || query.status === "ESCALATED") {
            showEscalationBanner();
        }

        // ADMIN ACTIONS
        if (isAdmin) {

            const container = document.getElementById("adminActions");

            if (container) {
                container.innerHTML = "";

                // Show resolve button ONLY if query is active
                if (!isClosed) {

                    const btn = document.createElement("button");
                    btn.innerText = "Resolve Query";
                    btn.className = "resolve-btn";

                    btn.onclick = () => resolveQuery(queryId);

                    container.appendChild(btn);
                }
            }
        }

    })
    .catch(err => console.error("Meta load failed", err));
}


// LOAD MESSAGES
function loadMessages(queryId) {

    const token = localStorage.getItem("token");

    fetch(`http://localhost:8080/api/query/${queryId}/messages`, {
        headers: {
            "Authorization": "Bearer " + token
        }
    })
    .then(res => res.json())
    .then(data => {

        const chatBox = document.getElementById("chatBox");
        chatBox.innerHTML = "";

        data.forEach(msg => {

            const div = document.createElement("div");
            div.classList.add("message");

            // Safe sender handling
            const sender = (msg.sender || "").toUpperCase();

            if (sender === "USER") {
                div.classList.add("user");
            } else if (sender === "AI") {
                div.classList.add("ai");
            } else if (sender === "ADMIN") {
                div.classList.add("admin");
            } else {
                div.classList.add("user"); // fallback
            }

            div.innerText = msg.content;
            chatBox.appendChild(div);
        });

        chatBox.scrollTop = chatBox.scrollHeight;

    })
    .catch(err => {
        console.error("Failed to load messages", err);
    });
}


// SEND MESSAGE
function sendMessage() {

    const input = document.getElementById("messageInput");
    const message = input.value.trim();

    if (!message) return;

    const token = localStorage.getItem("token");
    const queryId = window.currentQueryId;
    const isAdmin = window.isAdmin;

    const chatBox = document.getElementById("chatBox");

    // Correct role-based rendering
    const msgDiv = document.createElement("div");
    msgDiv.className = isAdmin
        ? "message admin"
        : "message user";

    msgDiv.innerText = message;
    chatBox.appendChild(msgDiv);

    input.value = "";

    // Typing indicator (ONLY for user → AI)
    let typingDiv = null;

    if (!isAdmin) {
        typingDiv = document.createElement("div");
        typingDiv.className = "message ai";
        typingDiv.innerText = "Typing...";
        chatBox.appendChild(typingDiv);
    }

    chatBox.scrollTop = chatBox.scrollHeight;

    // API endpoint
    const url = isAdmin
        ? `http://localhost:8080/api/admin/${queryId}/reply`
        : `http://localhost:8080/api/query/${queryId}/messages`;

    const headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + token
    };

    if (isAdmin) {
        headers["ADMIN_SECRET"] = sessionStorage.getItem("admin_secret");
    }

    fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify({ message })
    })
    .then(res => res.json())
    .then(data => {

        // Remove typing (only for user)
        if (typingDiv) typingDiv.remove();

        // Admin → DO NOT render again (already shown)
        if (!isAdmin) {
            const aiDiv = document.createElement("div");
            aiDiv.className = "message ai";
            aiDiv.innerText = data.content;

            chatBox.appendChild(aiDiv);
        }

        chatBox.scrollTop = chatBox.scrollHeight;

        loadQueryMeta(queryId, isAdmin);
    })
    .catch(err => {
        console.error("Send failed", err);
        if (typingDiv) typingDiv.innerText = "Error sending message";
    });
}


// ENTER
function handleKey(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
}


// ESCALATION
function showEscalationBanner() {

    if (document.getElementById("escalationBanner")) return;

    const banner = document.createElement("div");
    banner.id = "escalationBanner";
    banner.innerText = "Support agent will respond soon";

    const chatBox = document.getElementById("chatBox");
    chatBox.parentNode.insertBefore(banner, chatBox);
}


// BACK
function goBack() {
    redirectBack(window.isAdmin);
}


// REDIRECT FIX
function redirectBack(isAdmin) {
    if (isAdmin) {
        window.location.href = "query-monitor.html";
    } else {
        window.location.href = "my-queries.html";
    }
}

function resolveQuery(queryId) {

    const token = localStorage.getItem("token");
    const adminSecret = sessionStorage.getItem("admin_secret");

    if (!adminSecret) {
        alert("Admin verification required");
        return;
    }

    if (!confirm("Mark this query as resolved?")) return;

    fetch(`http://localhost:8080/api/admin/${queryId}/resolve`, {
        method: "POST",
        headers: {
            "Authorization": "Bearer " + token,
            "ADMIN_SECRET": adminSecret
        }
    })
    .then(res => {
        if (!res.ok) throw new Error("Resolve failed");
        return res.json();
    })
    .then(() => {
        alert("Query resolved");

        // refresh UI
        loadQueryMeta(queryId, true);

        // disable input
        document.getElementById("messageInput").disabled = true;
        document.getElementById("sendBtn").disabled = true;
    })
    .catch(err => {
        console.error(err);
        alert("Failed to resolve query");
    });
}