const API = "http://localhost:8080/api/admin";

function getToken() {
    return localStorage.getItem("token");
}

function getAdminSecret() {
    return sessionStorage.getItem("admin_secret");
}

function getUserId() {
    const params = new URLSearchParams(window.location.search);
    return params.get("id");
}

// LOAD USER DETAILS
async function loadUser() {
    const id = getUserId();

    console.log("Loading user:", id);

    try {
        const res = await fetch(`${API}/user/${id}`, {
            headers: {
                "Authorization": "Bearer " + getToken(),
                "ADMIN_SECRET": getAdminSecret()
            }
        });

        if (!res.ok) {
            const err = await res.text();
            console.error("API Error:", err);
            return;
        }

        const data = await res.json();
        console.log("User data:", data);

        // USER INFO
        document.getElementById("username").innerText = data.username;
        document.getElementById("email").innerText = data.email;

        // STATS
        document.getElementById("total").innerText = data.totalQueries;
        document.getElementById("pending").innerText = data.pending;
        document.getElementById("resolved").innerText = data.resolved;
        document.getElementById("escalated").innerText = data.escalated;
        document.getElementById("withdrawn").innerText = data.withdrawn; // NEW

        // TABLE
        const tbody = document.querySelector("#queryTable tbody");
        tbody.innerHTML = "";

        data.queries.forEach(q => {
            const row = document.createElement("tr");

            // status class
            let statusClass = "";
            if (q.status === "PENDING") statusClass = "status-pending";
            else if (q.status === "RESOLVED") statusClass = "status-resolved";
            else if (q.status === "ESCALATED") statusClass = "status-escalated";
            else if (q.status === "WITHDRAWN") statusClass = "status-withdrawn";

            row.innerHTML = `
                <td>${q.queryId}</td>
                <td class="${statusClass}">${q.status}</td>
                <td>${q.description}</td>
                <td>${formatDate(q.createdAt)}</td>
            `;

            tbody.appendChild(row);
        });

    } catch (err) {
        console.error("Fetch error:", err);
    }
}

// FORMAT DATE
function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleString();
}

// BACK BUTTON
document.querySelector(".back-btn").onclick = () => {
    window.location.href = "user-registry.html";
};

// INIT
loadUser();