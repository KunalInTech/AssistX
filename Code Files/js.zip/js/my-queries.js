document.addEventListener("DOMContentLoaded", () => {
    loadQueries();

    if (typeof startParticles === "function") {
        startParticles();
    }
});

function loadQueries() {

    const token = localStorage.getItem("token");

    if (!token) {
        alert("Session expired. Please login again.");
        window.location.href = "/login.html";
        return;
    }

    const container = document.getElementById("queryList");
    container.innerHTML = "<p style='color:white;'>Loading...</p>";

    fetch("http://localhost:8080/api/query/my", {
        method: "GET",
        headers: {
            "Authorization": "Bearer " + token
        }
    })
    .then(res => {
        if (!res.ok) throw new Error("Failed to fetch queries");
        return res.json();
    })
    .then(data => {

        // ✅ SORT (DTO-safe)
        data.sort((a, b) => {

            const order = {
                ESCALATED: 0,
                PENDING: 1,
                RESOLVED: 2,
                WITHDRAWN: 3
            };

            const aOrder = order[a.status] ?? 4;
            const bOrder = order[b.status] ?? 4;

            if (aOrder !== bOrder) return aOrder - bOrder;

            return new Date(b.createdAt) - new Date(a.createdAt);
        });

        container.innerHTML = "";

        if (data.length === 0) {
            container.innerHTML = "<p style='color:white;'>No queries yet.</p>";
            return;
        }

        data.forEach(q => {

            const card = document.createElement("div");
            card.className = "query-card";

            // ✅ OPEN CHAT
            card.onclick = () => {
                window.location.href = `chat.html?id=${q.id}`;
            };

            card.innerHTML = `
                <h3>Query #${q.id}</h3>
                <p>${q.description}</p>

                <p>
                    <b>Status:</b>
                    <span class="status ${q.status}">
                        ${q.status}
                    </span>
                </p>

                <p><b>Date:</b> ${formatDate(q.createdAt)}</p>

                ${
                    q.status === "PENDING"
                    ? `<button class="withdraw-btn" data-id="${q.id}">
                        Withdraw
                       </button>`
                    : ""
                }
            `;

            container.appendChild(card);
        });

        // ✅ FIX: Prevent click bubbling (VERY IMPORTANT)
        document.querySelectorAll(".withdraw-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                e.stopPropagation(); // 🔥 FIX
                withdrawQuery(btn.dataset.id);
            });
        });

    })
    .catch(err => {
        console.error(err);
        container.innerHTML = "<p style='color:red;'>Error loading queries</p>";
    });
}

// WITHDRAW
function withdrawQuery(id) {

    const token = localStorage.getItem("token");

    if (!confirm("Are you sure you want to withdraw this query?")) return;

    fetch(`http://localhost:8080/api/query/withdraw/${id}`, {
        method: "POST",
        headers: {
            "Authorization": "Bearer " + token
        }
    })
    .then(res => {
        if (!res.ok) throw new Error("Withdraw failed");
        return res.json();
    })
    .then(() => {
        alert("Query withdrawn");
        loadQueries();
    })
    .catch(err => {
        console.error(err);
        alert("Failed to withdraw");
    });
}

// FORMAT DATE
function formatDate(dateStr) {
    if (!dateStr) return "N/A";
    return new Date(dateStr).toLocaleString();
}

// BACK
function goBack() {
    window.location.href = "user-dashboard.html";
}