const API = "http://localhost:8080/api/admin";

function getToken() {
    return localStorage.getItem("token");
}

function getAdminSecret() {
    return sessionStorage.getItem("admin_secret");
}

// LOAD QUERIES
async function loadQueries() {
    try {
        console.log("Fetching queries...");

        const res = await fetch(`${API}/all`, {
            headers: {
                "Authorization": "Bearer " + getToken(),
                "ADMIN_SECRET": getAdminSecret()
            }
        });

        if (!res.ok) {
            console.error("Failed to fetch queries");
            return;
        }

        const data = await res.json();

        console.log("Queries received:", data);

        // SORT BY DATE DESC
        data.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        renderSections(data);

    } catch (err) {
        console.error("Error loading queries:", err);
    }
}

// GROUP + RENDER
function renderSections(data) {

    const container = document.getElementById("container");
    container.innerHTML = "";

    const groups = {
        ESCALATED: [],
        PENDING: [],
        RESOLVED: [],
        WITHDRAWN: []
    };

    data.forEach(q => {
        if (groups[q.status]) {
            groups[q.status].push(q);
        }
    });

    const order = ["ESCALATED", "PENDING", "RESOLVED", "WITHDRAWN"];

    order.forEach(status => {
        renderSection(status, groups[status], container);
    });
}

// RENDER ONE SECTION
function renderSection(title, queries, container) {

    const section = document.createElement("div");
    section.className = "section";

    section.innerHTML = `
        <h3>${title}</h3>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Description</th>
                        <th>Created</th>
                    </tr>
                </thead>
                <tbody>
                    ${
                        queries.length === 0
                        ? `<tr><td colspan="4" style="text-align:center;">No queries</td></tr>`
                        : queries.map(q => `
                            <tr onclick="openQuery(${q.queryId})">
                                <td>${q.queryId}</td>
                                <td>${q.username}</td>
                                <td>${q.description}</td>
                                <td>${formatDate(q.createdAt)}</td>
                            </tr>
                        `).join("")
                    }
                </tbody>
            </table>
        </div>
    `;

    container.appendChild(section);
}

// OPEN CHAT
function openQuery(id) {
    console.log("Opening query:", id);
    window.location.href = `chat.html?queryId=${id}&admin=true`;
}

// DATE FORMAT
function formatDate(d) {
    return new Date(d).toLocaleString();
}

// BACK
document.querySelector(".back-btn").onclick = () => {
    window.location.href = "admin-dashboard.html";
};

// INIT
loadQueries();