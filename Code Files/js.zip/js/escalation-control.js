document.addEventListener("DOMContentLoaded", () => {

    const token = localStorage.getItem("token");
    const adminSecret = sessionStorage.getItem("admin_secret");

    if (!token || !adminSecret) {
        alert("Unauthorized");
        window.location.href = "/login.html";
        return;
    }

    if (typeof startParticles === "function") {
            startParticles();
        }

    loadEscalatedQueries();
});

async function loadEscalatedQueries() {

    try {
        const res = await fetch("http://localhost:8080/api/admin/escalated", {
            headers: {
                "Authorization": "Bearer " + localStorage.getItem("token"),
                "ADMIN_SECRET": sessionStorage.getItem("admin_secret")
            }
        });

        if (!res.ok) {
            throw new Error("Failed to fetch");
        }

        const data = await res.json();

        const tableBody = document.getElementById("tableBody");
        tableBody.innerHTML = "";

        if (data.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="4">No escalated queries 🎉</td>
                </tr>
            `;
            return;
        }

        data.forEach(q => {

            const row = document.createElement("tr");

            // 🚨 Urgency check (older than 2 hours)
            const age = Date.now() - new Date(q.createdAt).getTime();
            if (age > 2 * 60 * 60 * 1000) {
                row.classList.add("urgent");
            }

            row.innerHTML = `
                <td>${q.id}</td>
                <td>${q.username}</td>
                <td>${q.description}</td>
                <td>${formatDate(q.createdAt)}</td>
            `;

            // CLICK → OPEN CHAT
            row.addEventListener("click", () => {
                window.location.href = `chat.html?id=${q.id}&admin=true`;
            });

            tableBody.appendChild(row);
        });

    } catch (err) {
        console.error(err);
        document.getElementById("tableBody").innerHTML = `
            <tr>
                <td colspan="4">Error loading queries</td>
            </tr>
        `;
    }
}

// FORMAT DATE
function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleString();
}

// BACK BUTTON
function goBack() {
    window.location.href = "admin-dashboard.html";
}