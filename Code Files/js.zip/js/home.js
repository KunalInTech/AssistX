(() => {


const token = localStorage.getItem("token");
const role = localStorage.getItem("role");

if (typeof startParticles === "function") {
    startParticles();
}

})();
