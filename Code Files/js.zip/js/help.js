document.addEventListener("DOMContentLoaded", () => {

    // START PARTICLES
    startParticles();

    // ACCORDION FUNCTIONALITY
    document.querySelectorAll(".faq-item").forEach(item => {
        item.addEventListener("click", () => {
            item.classList.toggle("active");
        });
    });

    // SEARCH FUNCTION
    const search = document.getElementById("search");

    if (search) {
        search.addEventListener("input", () => {
            const value = search.value.toLowerCase();

            document.querySelectorAll(".faq-item").forEach(item => {
                const text = item.innerText.toLowerCase();

                item.style.display = text.includes(value) ? "block" : "none";
            });
        });
    }
});

// BACK TO DASHBOARD FUNCTION
function goBack() {
    window.location.href = "user-dashboard.html";
}