const API = "http://localhost:8080/api/admin";

function getToken() {
    return localStorage.getItem("token");
}

function getAdminSecret() {
    return sessionStorage.getItem("admin_secret");
}

// LOAD USERS
async function loadUsers(search = "") {
    try {
        const res = await fetch(`${API}/users?search=${search}`, {
            headers: {
                "Authorization": "Bearer " + getToken(),
                "ADMIN_SECRET": getAdminSecret()
            }
        });

        const users = await res.json();
        renderUsers(users);

    } catch (err) {
        console.error("Error loading users:", err);
    }
}

// ACTIVE CHECK
function isActive(lastActiveAt) {
    if (!lastActiveAt) return false;

    const last = new Date(lastActiveAt);
    const now = new Date();

    return (now - last) / 1000 < 300;
}

// RENDER TABLE
function renderUsers(users) {
    const tbody = document.querySelector("#userTable tbody");
    tbody.innerHTML = "";

    if (!users || users.length === 0) {
        tbody.innerHTML = `<tr><td colspan="3">No users found</td></tr>`;
        return;
    }

    users.forEach(user => {
        const active = isActive(user.lastActiveAt);

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>
                <div class="status-dot ${active ? "green" : "red"}"></div>
            </td>
            <td>${user.username}</td>
            <td>${user.email}</td>
        `;

        row.onclick = () => {
            window.location.href = `user-details.html?id=${user.id}`;
        };

        tbody.appendChild(row);
    });
}

// SEARCH
document.getElementById("searchBtn").onclick = () => {
    const value = document.getElementById("searchInput").value;
    loadUsers(value);
};

// BACK
document.querySelector(".logout-btn").onclick = () => {
    window.location.href = "admin-dashboard.html";
};

// INIT
loadUsers();