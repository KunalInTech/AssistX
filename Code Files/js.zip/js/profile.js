const API = "http://localhost:8080/api/user";

// 🔐 GET TOKEN FROM LOCAL STORAGE
const token = localStorage.getItem("token");

// 🚨 SESSION CHECK
if (!token) {
    alert("Session expired. Please login again.");
    window.location.href = "login.html";
}

// 🌌 START PARTICLES
startParticles();

// 🔹 LOAD PROFILE
async function loadProfile() {
    try {
        const res = await fetch(`${API}/me`, {
            headers: {
                "Authorization": "Bearer " + token
            }
        });

        if (!res.ok) throw new Error("Unauthorized");

        const user = await res.json();

        document.getElementById("username").innerText = user.username;
        document.getElementById("email").innerText = user.email;

    } catch (err) {
        alert("Failed to load profile. Please login again.");
        localStorage.removeItem("token");
        window.location.href = "login.html";
    }
}

// 🔹 UPDATE USERNAME
async function updateUsername() {
    const username = document.getElementById("newUsername").value.trim();

    if (!username) {
        alert("Username cannot be empty");
        return;
    }

    try {
        const res = await fetch(`${API}/update-username`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({ username })
        });

        const data = await res.json();

        if (!res.ok) throw new Error(data.message);

        alert("Username updated!");
        loadProfile();

    } catch (err) {
        alert(err.message || "Error updating username");
    }
}

// 🔹 UPDATE EMAIL
async function updateEmail() {
    const email = document.getElementById("newEmail").value.trim();
    const password = document.getElementById("emailPassword").value;

    if (!email || !password) {
        alert("All fields required");
        return;
    }

    try {
        const res = await fetch(`${API}/update-email`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();

        if (!res.ok) throw new Error(data.message);

        alert("Email updated! Please login again.");

        // ⚠️ IMPORTANT: token now invalid (email changed)
        localStorage.removeItem("token");
        window.location.href = "login.html";

    } catch (err) {
        alert(err.message || "Error updating email");
    }
}

// 🔹 CHANGE PASSWORD
async function changePassword() {
    const oldPassword = document.getElementById("oldPassword").value;
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (!oldPassword || !newPassword || !confirmPassword) {
        alert("All fields required");
        return;
    }

    try {
        const res = await fetch(`${API}/change-password`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({
                oldPassword,
                newPassword,
                confirmPassword
            })
        });

        const data = await res.json();

        if (!res.ok) throw new Error(data.message);

        alert("Password changed successfully!");

    } catch (err) {
        alert(err.message || "Error changing password");
    }
}

// 🔹 BACK
function goBack() {
    window.location.href = "user-dashboard.html";
}

// INIT
loadProfile();