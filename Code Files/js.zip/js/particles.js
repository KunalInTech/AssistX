// Particle Background (Controlled Start)

let particleCanvas = null;
let particleCtx = null;
let particleWidth = 0;
let particleHeight = 0;
let particleList = [];
let particleAnimationId = null;

class Particle {
    constructor() {
        this.reset();
    }

    reset() {
        this.x = Math.random() * particleWidth;
        this.y = Math.random() * particleHeight;
        this.radius = Math.random() * 2 + 0.5;
        this.speed = Math.random() + 0.5;
    }

    update() {
        this.y += this.speed;
        if (this.y > particleHeight) {
            this.y = 0;
            this.x = Math.random() * particleWidth;
        }
    }

    draw() {
        particleCtx.beginPath();
        particleCtx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        particleCtx.fillStyle = "rgba(255,255,255,0.8)";
        particleCtx.fill();
    }
}

function resizeParticles() {
    if (!particleCanvas) return;
    particleWidth = particleCanvas.width = window.innerWidth;
    particleHeight = particleCanvas.height = window.innerHeight;
}

function animateParticles() {
    if (!particleCtx) return;

    particleCtx.clearRect(0, 0, particleWidth, particleHeight);
    particleList.forEach(p => {
        p.update();
        p.draw();
    });

    particleAnimationId = requestAnimationFrame(animateParticles);
}

/*  Call this when you WANT particles to start*/
function startParticles() {
    if (particleAnimationId) return; // prevent double start

    particleCanvas = document.getElementById("particles");
    if (!particleCanvas) {
        console.warn("Particles canvas not found. Skipping particles.");
        return;
    }

    particleCtx = particleCanvas.getContext("2d");
    if (!particleCtx) {
        console.warn("Particles context unavailable.");
        return;
    }

    resizeParticles();
    window.addEventListener("resize", resizeParticles);

    particleList = [];
    for (let i = 0; i < 120; i++) {
        particleList.push(new Particle());
    }

    animateParticles();
}

/* optional: stop animation if needed */
function stopParticles() {
    if (particleAnimationId) {
        cancelAnimationFrame(particleAnimationId);
        particleAnimationId = null;
    }
}