const moon = document.getElementById("moon");
const card = document.getElementById("loginCard");

let parallaxEnabled = false;

window.addEventListener("load", () => {

    /* ✨ START PARTICLES IMMEDIATELY (background ambience) */
    if (typeof startParticles === "function") {
        startParticles();
    }

    /* 🌕 STEP 1: Moon rises from below the screen */
    setTimeout(() => {
        moon.style.transform = "translate(-50%, -50%)";
    }, 400);

    /* 🪟 STEP 2: Moon morphs into login card */
    setTimeout(() => {
        moon.style.width = "340px";
        moon.style.height = "420px";
        moon.style.borderRadius = "16px";
        moon.style.boxShadow = "0 0 40px rgba(0, 0, 0, 0.6)";
        moon.style.background = "rgba(255, 255, 255, 0.08)";
        moon.style.backdropFilter = "blur(15px)";

        card.classList.remove("hidden");
        card.style.opacity = "1";
    }, 2100);

    /* 🧠 STEP 3: Enable parallax after UI settles */
    setTimeout(() => {
        parallaxEnabled = true;
    }, 2600);
});

/* Subtle Parallax Effect */

document.addEventListener("mousemove", (e) => {
    if (!parallaxEnabled) return;

    const rect = card.getBoundingClientRect();
    const cardX = rect.left + rect.width / 2;
    const cardY = rect.top + rect.height / 2;

    const deltaX = e.clientX - cardX;
    const deltaY = e.clientY - cardY;

    const rotateX = (-deltaY / 80).toFixed(2);
    const rotateY = (deltaX / 80).toFixed(2);

    card.style.transform =
        `translate(-50%, -50%) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
});
