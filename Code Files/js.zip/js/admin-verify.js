let token = null;

// TOKEN VALIDATOR
function isValidToken(token) {
    return token && token.includes(".") && token.split(".").length === 3;
}

window.onload = () => {

    // Start particles
    if (typeof startParticles === "function") {
        startParticles();
    }

    // Show card
    setTimeout(() => {
        const card = document.getElementById("verifyCard");
        if (card) card.classList.remove("hidden");
    }, 300);

    // Extract token from URL
    const params = new URLSearchParams(window.location.search);
    const tokenFromUrl = params.get("token");

    // FIX 1: Validate token before using it
    if (isValidToken(tokenFromUrl)) {
        token = tokenFromUrl;
        localStorage.setItem("token", token);

        // Clean URL (remove token from browser)
        window.history.replaceState({}, document.title, "/admin-verify.html");

    } else {
        // FIX 2: fallback to stored token
        const storedToken = localStorage.getItem("token");

        if (isValidToken(storedToken)) {
            token = storedToken;
        } else {
            // FIX 3: no valid token at all → redirect
            localStorage.clear();
            window.location.href = "/login.html";
            return;
        }
    }

    // Attach verify button
    const btn = document.getElementById("verifyBtn");
    if (btn) {
        btn.addEventListener("click", verifyAdmin);
    }
};

// ================= VERIFY ADMIN =================
function verifyAdmin() {

    const secret = document.getElementById("adminSecret").value.trim();
    const msg = document.getElementById("errorMsg");

    console.log("Entered Admin Secret:", secret ? "YES" : "NO");

    if (!secret) {
        msg.innerText = "Please enter admin secret";
        return;
    }

    if (!isValidToken(token)) {
        msg.innerText = "Session expired. Please login again.";
        localStorage.clear();
        window.location.href = "/login.html";
        return;
    }

    fetch("http://localhost:8080/api/auth/verify-admin", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify({ secret })
    })
    .then(res => {
        console.log("Verify response status:", res.status);

        if (!res.ok) throw new Error("Invalid secret");
        return res.text();
    })
    .then(() => {

        console.log("Admin verified successfully");

        // CRITICAL FIX (THIS WAS MISSING)
        sessionStorage.setItem("admin_secret", secret);

        // Optional debug
        console.log("Stored admin_secret in sessionStorage");

        // Promote role (UI purpose)
        localStorage.setItem("role", "ADMIN");

        // Redirect
        window.location.href = "/admin-dashboard.html";
    })
    .catch(() => {
        console.error("Invalid admin secret");
        msg.innerText = "Invalid admin secret";
    });
}