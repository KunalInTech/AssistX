(() => {

    /* ✨ Particles already running */
    if (typeof startParticles === "function") {
        startParticles();
    }

    const constellationCanvas = document.getElementById("constellation");
    const ctx = constellationCanvas.getContext("2d");
    const card = document.getElementById("registerCard");

    let w, h;
    let stars = [];
    let animationFrame;

    let linesEnabled = false;
    let lineProgress = 0;

    function resize() {
        w = constellationCanvas.width = window.innerWidth;
        h = constellationCanvas.height = window.innerHeight;
    }
    window.addEventListener("resize", resize);
    resize();

    /* ⭐ STAR SETUP (static first) */
    class Star {
        constructor() {
            this.x = Math.random() * w;
            this.y = Math.random() * h;
            this.r = Math.random() * 2.2 + 1;
        }
        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
            ctx.fillStyle = "rgba(255,255,255,0.95)";
            ctx.fill();
        }
    }

    for (let i = 0; i < 50; i++) {
        stars.push(new Star());
    }

    /* 🧵 LINE DRAWING (progressive) */
    function drawLines(progress) {
        ctx.strokeStyle = "rgba(255,255,255,0.55)";
        ctx.lineWidth = 1;

        stars.forEach((a, i) => {
            for (let j = i + 1; j < stars.length; j++) {
                const b = stars[j];
                const dx = a.x - b.x;
                const dy = a.y - b.y;
                const dist = Math.sqrt(dx * dx + dy * dy);

                if (dist < 140) {
                    const x = a.x + (b.x - a.x) * progress;
                    const y = a.y + (b.y - a.y) * progress;

                    ctx.beginPath();
                    ctx.moveTo(a.x, a.y);
                    ctx.lineTo(x, y);
                    ctx.stroke();
                }
            }
        });
    }

    /* 🎬 MAIN LOOP */
    function animate() {
        ctx.clearRect(0, 0, w, h);

        // Stars always visible
        stars.forEach(s => s.draw());

        // Lines animate slowly
        if (linesEnabled) {
            drawLines(lineProgress);
            lineProgress = Math.min(lineProgress + 0.012, 1); // ⬅ slower
        }

        animationFrame = requestAnimationFrame(animate);
    }

    animate();

    /* 🕒 TIMELINE CONTROL */

    // Let stars breathe
    setTimeout(() => {
        linesEnabled = true;
    }, 1200);

    // Reveal register card after lines mostly form
    setTimeout(() => {
        card.classList.remove("hidden");
        card.style.opacity = "1";
    }, 2600);

    // Fade constellation gently
    setTimeout(() => {
        constellationCanvas.style.opacity = "0";
    }, 3200);

    // Remove constellation fully
    setTimeout(() => {
        cancelAnimationFrame(animationFrame);
        constellationCanvas.classList.add("hidden");
    }, 4000);

})();
