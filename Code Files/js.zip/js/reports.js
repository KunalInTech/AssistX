document.addEventListener("DOMContentLoaded", () => {

    // Start particles (clean separation)
    if (typeof startParticles === "function") {
        startParticles();
    }

    loadAnalytics();
});

function loadAnalytics() {

    const adminSecret = sessionStorage.getItem("admin_secret");

    // Safety check
    if (!adminSecret) {
        alert("Unauthorized access");
        window.location.href = "admin-login.html";
        return;
    }

    fetch("http://localhost:8080/api/admin/analytics", {
        headers: {
            "ADMIN_SECRET": adminSecret
        }
    })
    .then(res => {
        if (!res.ok) {
            throw new Error("API Error: " + res.status);
        }
        return res.json();
    })
    .then(data => {

        console.log("Analytics:", data);

        const grid = document.getElementById("statsGrid");

        grid.innerHTML = `
            ${card("Total Queries", data.total)}
            ${card("Pending", data.pending)}
            ${card("Resolved", data.resolved)}
            ${card("Withdrawn", data.withdrawn, "highlight-danger")}
            ${card("Escalated", data.escalated, "highlight-warning")}
            ${card("AI Resolved", data.aiResolved, "highlight-ai")}
            ${card("Admin Resolved", data.adminResolved, "highlight-admin")}
            ${card("Avg Resolution (mins)", formatNumber(data.avgResolutionTime))}
        `;
    })
    .catch(err => {
        console.error("Failed to load analytics", err);
        alert("Error loading analytics");
    });
}

function card(title, value, extraClass = "") {
    return `
        <div class="card">
            <h3>${title}</h3>
            <p class="${extraClass}">${value}</p>
        </div>
    `;
}

// Safe number formatting
function formatNumber(value) {
    if (value === null || value === undefined) return "0";
    return Number(value).toFixed(1);
}

// Navigation
function goBack() {
    window.location.href = "admin-dashboard.html";
}