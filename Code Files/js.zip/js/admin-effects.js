(() => {

    // TOKEN VALIDATOR
    function isValidToken(token) {
        return token && token.includes(".") && token.split(".").length === 3;
    }

    // AUTH CHECK
    const token = localStorage.getItem("token");
    const role = localStorage.getItem("role");

    if (!isValidToken(token) || role !== "ADMIN") {
        localStorage.clear();
        window.location.href = "/login.html";
        return;
    }

    // LOGOUT
    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.clear();
            sessionStorage.clear();
            window.location.href = "/login.html";
        });
    }

    // PARTICLES
    if (typeof startParticles === "function") {
        startParticles();
    }

    // COMET SETUP
    const cometCanvas = document.getElementById("comet");
    if (!cometCanvas) return;

    const ctx = cometCanvas.getContext("2d");
    const dashboard = document.getElementById("adminDashboard");

    let w, h;
    let cometX = -600;
    let cometY;
    let speed = 14;
    let animationFrame;
    let tailLength = 520;

    function resize() {
        w = cometCanvas.width = window.innerWidth;
        h = cometCanvas.height = window.innerHeight;
        cometY = h * 0.35;
    }

    window.addEventListener("resize", resize);
    resize();

    function drawComet() {
        ctx.clearRect(0, 0, w, h);

        const gradient = ctx.createLinearGradient(
            cometX - tailLength, cometY,
            cometX, cometY
        );

        gradient.addColorStop(0, "rgba(255,255,255,0)");
        gradient.addColorStop(0.6, "rgba(255,255,255,0.25)");
        gradient.addColorStop(1, "rgba(255,255,255,0.9)");

        ctx.beginPath();
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 7;
        ctx.moveTo(cometX - tailLength, cometY);
        ctx.lineTo(cometX, cometY);
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(cometX, cometY, 10, 0, Math.PI * 2);
        ctx.fillStyle = "white";
        ctx.shadowColor = "rgba(255,255,255,0.85)";
        ctx.shadowBlur = 22;
        ctx.fill();
        ctx.shadowBlur = 0;
    }

    function animate() {
        cometX += speed;
        drawComet();

        animationFrame = requestAnimationFrame(animate);

        if (dashboard &&
            cometX > w * 0.35 &&
            dashboard.classList.contains("hidden")) {

            dashboard.classList.remove("hidden");
            dashboard.classList.add("visible");
        }

        if (cometX > w + tailLength) {
            cancelAnimationFrame(animationFrame);
            ctx.clearRect(0, 0, w, h);

            cometCanvas.style.opacity = "0";

            setTimeout(() => {
                cometCanvas.style.display = "none";
            }, 600);
        }
    }

    // ================= LOAD STATS =================
    async function loadStats() {

        const adminSecret = sessionStorage.getItem("admin_secret");

        if (!token || !adminSecret) {
            console.warn("Missing auth for stats");
            return;
        }

        try {
            const res = await fetch("http://localhost:8080/api/admin/all", {
                headers: {
                    "Authorization": "Bearer " + token,
                    "ADMIN_SECRET": adminSecret
                }
            });

            if (!res.ok) {
                console.error("Failed to fetch stats");
                return;
            }

            const queries = await res.json();

            let total = queries.length;
            let pending = 0;
            let resolved = 0;
            let escalated = 0;

            queries.forEach(q => {
                if (q.status === "PENDING") pending++;
                else if (q.status === "RESOLVED") resolved++;
                else if (q.status === "ESCALATED") escalated++;
            });

            document.getElementById("total").innerText = total;
            document.getElementById("pending").innerText = pending;
            document.getElementById("resolved").innerText = resolved;
            document.getElementById("escalated").innerText = escalated;

        } catch (err) {
            console.error("Stats error:", err);
        }
    }

    // INIT
    setTimeout(() => {
        animate();
        loadStats();
    }, 500);

})();