// TOKEN VALIDATOR
function isValidToken(token) {
    return token && token.includes(".") && token.split(".").length === 3;
}

// CATEGORY HANDLER
function handleCategoryChange() {
    const category = document.getElementById("category").value;

    const productDiv = document.getElementById("productDiv");
    const dateDiv = document.getElementById("dateDiv");

    if (["account", "feedback", "contact"].includes(category)) {
        productDiv.style.display = "none";
        dateDiv.style.display = "none";
    } else {
        productDiv.style.display = "block";
        dateDiv.style.display = "block";
    }
}

// RUN ON LOAD
document.addEventListener("DOMContentLoaded", () => {
    handleCategoryChange();
});


// 🎯 DYNAMIC SUCCESS MESSAGE GENERATOR
function getSuccessMessage(category) {

    // 🟢 FEEDBACK
    if (category === "feedback") {
        return `
            <b>Thank you for your feedback.</b><br>
            We truly appreciate you taking the time to share your thoughts with us.<br>
            Your input helps us improve and deliver a better experience.
        `;
    }

    // 🔵 CONTACT SUPPORT
    if (category === "contact") {
        return `
            <b>Your request has been received.</b><br>
            Our support team will reach out to you shortly to assist you further.
        `;
    }

    // 🟡 ACCOUNT
    if (category === "account") {
        return `
            <b>Your request has been submitted.</b><br>
            Our team is reviewing your account-related concern with priority.<br>
            You will be notified once it is resolved.
        `;
    }

    // ⚙️ DEFAULT
    return `
        <b>Your query has been submitted successfully.</b><br>
        Our team is currently reviewing your request.<br>
        You can track its status anytime from the <b>“My Queries”</b> section.
    `;
}


// MAIN SUBMIT FUNCTION
function submitForm() {

    const token = localStorage.getItem("token");

    // DEBUG: TOKEN INSPECTION
    console.log("===== TOKEN DEBUG START =====");
    console.log("RAW TOKEN:", token);
    console.log("TOKEN EXISTS:", !!token);
    console.log("TOKEN LENGTH:", token ? token.length : 0);
    console.log("TOKEN PARTS:", token ? token.split(".").length : "N/A");
    console.log("IS VALID TOKEN:", isValidToken(token));
    console.log("===== TOKEN DEBUG END =====");

    // FIX 1: STRICT TOKEN VALIDATION
    if (!isValidToken(token)) {
        console.error("INVALID TOKEN DETECTED");
        localStorage.clear();
        alert("Session expired. Please login again.");
        window.location.href = "/login.html";
        return;
    }

    const category = document.getElementById("category").value;
    const product = document.getElementById("product").value;
    const date = document.getElementById("date").value;
    const description = document.getElementById("description").value;

    console.log("FORM DATA:", {
        category,
        product,
        date,
        description
    });

    if (!category || !description) {
        alert("Please fill required fields");
        return;
    }

    // CATEGORY-BASED VALIDATION
    if (!["account", "feedback", "contact"].includes(category)) {
        if (!product || !date) {
            alert("Product name and purchase date are required for this category");
            return;
        }
    }

    // BUILD PAYLOAD
    const payload = {
        category: category,
        description: description
    };

    if (!["account", "feedback", "contact"].includes(category)) {
        payload.productName = product;
        payload.purchaseDate = date;
    }

    console.log("PAYLOAD BEING SENT:", payload);

    // FINAL REQUEST DEBUG
    console.log("SENDING REQUEST TO: http://localhost:8080/api/query/create");
    console.log("AUTH HEADER:", "Bearer " + token);

    fetch("http://localhost:8080/api/query/create", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify(payload)
    })
    .then(res => {

        console.log("RESPONSE STATUS:", res.status);
        console.log("RESPONSE OK?:", res.ok);

        if (!res.ok) {
            return res.text().then(text => {
                console.error("SERVER ERROR RESPONSE:", text);
                throw new Error(text || "Failed to create query");
            });
        }

        return res.json();
    })
    .then(data => {

        console.log("SUCCESS RESPONSE:", data);

        // 🎯 GET DYNAMIC MESSAGE
        const message = getSuccessMessage(category);

        // ✅ DISPLAY CLEAN SUCCESS UI
        document.getElementById("result").innerHTML = `
            <div style="
                background: rgba(46, 204, 113, 0.15);
                border: 1px solid rgba(46, 204, 113, 0.4);
                padding: 12px;
                border-radius: 10px;
                color: #d4f8e8;
            ">
                ✅ ${message}
            </div>
        `;

        // RESET FORM
        document.getElementById("description").value = "";
        document.getElementById("product").value = "";
        document.getElementById("date").value = "";
        document.getElementById("category").value = "";

        handleCategoryChange();

    })
    .catch(err => {
        console.error("FINAL ERROR:", err);
        alert("Error submitting query: " + err.message);
    });
}

// BACK TO DASHBOARD
function goBack() {
    window.location.href = "user-dashboard.html";
}