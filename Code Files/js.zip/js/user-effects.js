(() => {

    // TOKEN VALIDATOR
    function isValidToken(token) {
        return token && token.includes(".") && token.split(".").length === 3;
    }

    // ================= EXTRACT TOKEN =================
    const params = new URLSearchParams(window.location.search);
    const tokenFromUrl = params.get("token");

    if (isValidToken(tokenFromUrl)) {
        localStorage.setItem("token", tokenFromUrl);

        if (!localStorage.getItem("role")) {
            localStorage.setItem("role", "USER");
        }

        window.history.replaceState({}, document.title, "/user-dashboard.html");
    }

    // ================= READ AUTH =================
    let token = localStorage.getItem("token");
    let role = localStorage.getItem("role");

    if (!isValidToken(token) || role !== "USER") {
        localStorage.clear();
        window.location.href = "/login.html";
        return;
    }

    // ================= SET USERNAME =================
    const username = localStorage.getItem("username") || "USER";
    const usernameEl = document.getElementById("usernameDisplay");
    if (usernameEl) usernameEl.innerText = username;

    // ================= LOGOUT =================
    const logoutBtn = document.getElementById("logoutBtn");

    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.clear();
            sessionStorage.clear();
            window.location.href = "/login.html";
        });
    }

    // ================= PARTICLES =================
    if (typeof startParticles === "function") {
        startParticles();
    }

    // ================= SHOW DASHBOARD IMMEDIATELY =================
    const dashboard = document.getElementById("userDashboard");
    if (dashboard) {
        dashboard.classList.remove("hidden");
        dashboard.classList.add("visible");
    }

    // ================= LOAD USER STATS =================
    function loadUserStats() {

        fetch("http://localhost:8080/api/query/my", {
            headers: {
                "Authorization": "Bearer " + token
            }
        })
        .then(res => {
            if (!res.ok) throw new Error("Failed to fetch queries");
            return res.json();
        })
        .then(data => {

            console.log("User Queries:", data);

            const total = data.length;
            const pending = data.filter(q => q.status === "PENDING").length;
            const resolved = data.filter(q => q.status === "RESOLVED").length;

            const statValues = document.querySelectorAll(".stat-value");

            if (statValues.length >= 3) {
                statValues[0].innerText = total;
                statValues[1].innerText = pending;
                statValues[2].innerText = resolved;
            }

        })
        .catch(err => {
            console.error("Stats load failed:", err);
        });
    }

    //Load immediately (no delay now)
    loadUserStats();

})();