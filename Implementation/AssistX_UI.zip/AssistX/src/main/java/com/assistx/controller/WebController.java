package com.assistx.controller;

import com.assistx.entity.QueryEntity;
import com.assistx.entity.UserEntity;
import com.assistx.service.QueryService;
import com.assistx.service.UserServiceImpl;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.List;
import java.util.Optional;

@Controller
public class WebController {

    @Autowired
    private UserServiceImpl userService;

    @Autowired
    private QueryService queryService;

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/login")
    public String showLogin() {
        return "login";
    }

    @PostMapping("/login")
    public String handleLogin(@RequestParam String username,
                            @RequestParam String password,
                            HttpSession session,
                            RedirectAttributes redirectAttributes) {
        Optional<UserEntity> user = userService.authenticateUser(username, password);
        if (user.isPresent()) {
            session.setAttribute("user", user.get());
            return "redirect:/dashboard";
        } else {
            redirectAttributes.addFlashAttribute("error", "Invalid username or password");
            return "redirect:/login";
        }
    }

    @GetMapping("/register")
    public String showRegister() {
        return "register";
    }

    @PostMapping("/register")
    public String handleRegister(@ModelAttribute UserEntity user,
                                RedirectAttributes redirectAttributes) {
        try {
            userService.registerUser(user);
            redirectAttributes.addFlashAttribute("success", "Registration successful! Please login.");
            return "redirect:/login";
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/register";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        UserEntity user = (UserEntity) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        List<QueryEntity> userQueries = queryService.getQueriesByUser(user.getUserId());
        model.addAttribute("user", user);
        model.addAttribute("queries", userQueries);
        model.addAttribute("queryCount", userQueries.size());
        return "dashboard";
    }

    @GetMapping("/submit-query")
    public String showSubmitQuery(HttpSession session) {
        if (session.getAttribute("user") == null) {
            return "redirect:/login";
        }
        return "submit-query";
    }

    @PostMapping("/submit-query")
    public String handleSubmitQuery(@RequestParam String queryText,
                                   HttpSession session,
                                   RedirectAttributes redirectAttributes) {
        UserEntity user = (UserEntity) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        QueryEntity query = new QueryEntity(user.getUserId(), queryText);
        QueryEntity savedQuery = queryService.submitQuery(query);
        redirectAttributes.addFlashAttribute("success", "Query submitted successfully!");
        redirectAttributes.addFlashAttribute("queryResponse", savedQuery.getResponseText());
        return "redirect:/dashboard";
    }

    @GetMapping("/admin")
    public String adminDashboard(Model model) {
        List<QueryEntity> allQueries = queryService.getAllQueries();
        List<QueryEntity> escalatedQueries = queryService.getEscalatedQueries();
        List<UserEntity> allUsers = userService.getAllUsers();
        model.addAttribute("queries", allQueries);
        model.addAttribute("escalatedQueries", escalatedQueries);
        model.addAttribute("users", allUsers);
        model.addAttribute("stats", queryService.getQueryStatistics());
        return "admin";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}