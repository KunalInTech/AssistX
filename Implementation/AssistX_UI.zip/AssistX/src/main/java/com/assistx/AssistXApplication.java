package com.assistx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssistXApplication {

    public static void main(String[] args) {
        SpringApplication.run(AssistXApplication.class, args);
        System.out.println("\n" +
            "╔═══════════════════════════════════════════════════════════╗\n" +
            "║                                                           ║\n" +
            "║     ✨ ASSISTX - AI Customer Support System ✨           ║\n" +
            "║                                                           ║\n" +
            "║     🚀 Application started successfully!                 ║\n" +
            "║     🌐 Access at: http://localhost:8080                  ║\n" +
            "║                                                           ║\n" +
            "╚═══════════════════════════════════════════════════════════╝\n");
    }
}