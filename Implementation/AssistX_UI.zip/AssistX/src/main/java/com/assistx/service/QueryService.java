package com.assistx.service;

import com.assistx.entity.QueryEntity;
import com.assistx.repository.QueryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class QueryService {

    @Autowired
    private QueryRepository queryRepository;

    private static final Map<String, List<String>> CATEGORY_KEYWORDS = new HashMap<>();
    
    static {
        CATEGORY_KEYWORDS.put("BILLING", Arrays.asList("bill", "payment", "charge", "invoice", "refund"));
        CATEGORY_KEYWORDS.put("TECHNICAL", Arrays.asList("error", "bug", "crash", "broken", "problem"));
        CATEGORY_KEYWORDS.put("ACCOUNT", Arrays.asList("login", "password", "account", "username"));
        CATEGORY_KEYWORDS.put("PRODUCT", Arrays.asList("feature", "product", "how to", "usage"));
        CATEGORY_KEYWORDS.put("SHIPPING", Arrays.asList("delivery", "shipping", "order", "track"));
    }

    public QueryEntity submitQuery(QueryEntity query) {
        String category = classifyQuery(query.getQueryText());
        query.setCategory(category);
        
        String priority = calculatePriority(query.getQueryText());
        query.setPriority(priority);
        
        boolean shouldEscalate = shouldEscalate(priority, category);
        query.setIsEscalated(shouldEscalate);
        
        String response = generateResponse(category, shouldEscalate);
        query.setResponseText(response);
        
        if (shouldEscalate) {
            query.setStatus("ESCALATED");
        } else {
            query.setStatus("RESOLVED");
        }
        
        return queryRepository.save(query);
    }

    private String classifyQuery(String queryText) {
        String lower = queryText.toLowerCase();
        for (Map.Entry<String, List<String>> entry : CATEGORY_KEYWORDS.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (lower.contains(keyword)) {
                    return entry.getKey();
                }
            }
        }
        return "GENERAL";
    }

    private String calculatePriority(String queryText) {
        String lower = queryText.toLowerCase();
        if (lower.contains("urgent") || lower.contains("critical") || lower.contains("emergency")) {
            return "CRITICAL";
        } else if (lower.contains("important") || lower.contains("serious")) {
            return "HIGH";
        } else if (lower.contains("?")) {
            return "MEDIUM";
        }
        return "LOW";
    }

    private boolean shouldEscalate(String priority, String category) {
        return priority.equals("CRITICAL") || priority.equals("HIGH") || 
               category.equals("BILLING") || category.equals("ACCOUNT");
    }

    private String generateResponse(String category, boolean escalated) {
        if (escalated) {
            return "Thank you! Your query has been escalated to our support team. We'll contact you within 24 hours.";
        }
        switch (category) {
            case "BILLING": return "For billing inquiries, contact billing@assistx.com";
            case "TECHNICAL": return "Please try clearing cache. Our tech team will assist if needed.";
            case "ACCOUNT": return "Try 'Forgot Password' or contact support@assistx.com";
            case "PRODUCT": return "Visit help.assistx.com for guides and FAQs.";
            case "SHIPPING": return "Track your order in 'My Orders'. Delivery takes 3-5 days.";
            default: return "A support representative will respond within 24 hours.";
        }
    }

    public List<QueryEntity> getAllQueries() {
        return queryRepository.findAll();
    }

    public List<QueryEntity> getQueriesByUser(Long userId) {
        return queryRepository.findByUserIdOrderByTimestampDesc(userId);
    }

    public List<QueryEntity> getEscalatedQueries() {
        return queryRepository.findByIsEscalated(true);
    }

    public Map<String, Long> getQueryStatistics() {
        Map<String, Long> stats = new HashMap<>();
        stats.put("total", queryRepository.count());
        stats.put("pending", queryRepository.countByStatus("PENDING"));
        stats.put("resolved", queryRepository.countByStatus("RESOLVED"));
        stats.put("escalated", queryRepository.countByIsEscalated(true));
        return stats;
    }
}