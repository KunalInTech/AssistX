package com.assistx.repository;

import com.assistx.entity.QueryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface QueryRepository extends JpaRepository<QueryEntity, Long> {
    List<QueryEntity> findByUserId(Long userId);
    List<QueryEntity> findByStatus(String status);
    List<QueryEntity> findByIsEscalated(Boolean isEscalated);
    List<QueryEntity> findByUserIdOrderByTimestampDesc(Long userId);
    long countByStatus(String status);
    long countByIsEscalated(Boolean isEscalated);
}